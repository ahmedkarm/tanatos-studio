/*globle,console*/
$(function() {
  "use strict";

 //hidden 
        $('.our-works .sho').click(function() {
             $('.our-works .sho').fadeOut(200);
           $('.hid').fadeIn(3500);
        });
//slider
    var left = $('.test .fa-angle-left '),
        right = $('.test .fa-angle-right ');
    function check() {
        if($('.client:first').hasClass('active')){
            left.fadeOut();
        }else{
            left.fadeIn();
        }
        if($('.client:last').hasClass('active')){
            right.fadeOut();
        }else{
            right.fadeIn();
        }
    }check();
   $('.test i').click(function(){
       if($(this).hasClass('fa-angle-right')){
           $('.test .active').fadeOut(100,function(){
             $(this).removeClass('active').next('.client').addClass('active').fadeIn();
               check();
           });
       }else{
             $('.test .active').fadeOut(100,function(){
             $(this).removeClass('active').prev('.client').addClass('active').fadeIn();
               check();
           });
       }
   });
     
});
    



























